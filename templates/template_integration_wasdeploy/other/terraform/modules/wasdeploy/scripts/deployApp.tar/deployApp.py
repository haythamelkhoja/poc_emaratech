# =================================================================
# Copyright 2017 IBM Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =================================================================

import sys
import urllib

# Process Command Line Arguments

if len(sys.argv) != 4:
    print "Invalid number of arguments!"
    print "USAGE: wsadmin.sh -lang jython -profile wsadminlib.py -f deployApp.py app_uri target_type target_name appname"
    sys.exit(1)

app_uri=sys.argv[0]
target_type=sys.argv[1]
target_name=sys.argv[2]
appname=sys.argv[3]

sys.stderr.write("Deploying application with deployApp.py\n")
sys.stderr.write("app_uri:" + app_uri + "\n")
sys.stderr.write("target_type:" + target_type + "\n")
sys.stderr.write("target_name:" + target_name + "\n")

# Download Application File

filename = '/tmp/' + app_uri.split('/')[-1]
sys.stderr.write("filename:" + filename + "\n")

if os.path.exists(filename):
  os.remove(filename)

response = urllib.urlretrieve(app_uri, filename)

# Deploy Application

clusternames = []
servers = []
options = []

if target_type == 'cluster':
  target_name=target_name.strip(':')
  clusters.append(target_name)
elif target_type == 'server':
  nodename = target_name.split(":")[0]
  servername = target_name.split(":")[1]
  servers.append({"nodename":nodename, "servername":servername})

deleteApplicationByNameIfExists(appname)
installApplication( filename, servers, clusternames, options )
saveAndSync()
startApplication(appname)
